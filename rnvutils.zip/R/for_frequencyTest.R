#' Test the uniformity of random numbers using Frequency Test
#'
#' Performs test of hypothesis on the uniformity of random numbers using Frequency Test
#' @param randnums A vector of random numbers (each random number is from 0 to 1, inclusive)
#' @param nc The number of intervals from 0 to 1 to be used
#' @param alpha The level of significance for the test of hypothesis
#' @return A test of hypothesis including computed statistic, tabular value, p-value, and conclusion
#' @export
freq.test <- function(randnums,nc,alpha){
  n = length(randnums)
  p = 1 / nc
  expected = n * p #expected count for all intervals

  end = c()
  for(i in 1:nc){ #for-loop to get ends of all intervals
    end[i] = i * p
  }

  observed = c()
  for(e in 1:length(end)){ #for-loop to get all observed counts
    count = 0
    for(r in randnums){
      if(e == 1){
        if(r <= end[e]) count = count + 1
      }else{
        if(r <= end[e] & r > end[e-1]) count = count + 1
      }
    }
    observed[e] = count
  }

  #test of hypothesis
  df = length(observed) - 1
  chi.comp = sum(((observed - expected) ^ 2) / expected)
  chi.tab = qchisq(alpha,df,lower.tail = FALSE)
  pvalue = pchisq(chi.comp,df,lower.tail = FALSE)

  decision = ""
  conclusion = ""
  if(pvalue <= alpha){
    decision = "reject the null hypothesis"
    conclusion = "The random numbers does not follow the uniform distribution."
  }else{
    decision = "fail to reject the null hypothesis"
    conclusion = "The random numbers follow the uniform distribution."
  }

  cat("\n")
  cat("\tFREQUENCY TEST\n")
  cat("\n")
  cat("data:",n,"random numbers\n")
  cat("X-squared = ",chi.comp,", tab = ",chi.tab,", df = ",df,", p-value = ",pvalue,"\n\n",sep="")
  cat("null hypothesis: follow the uniform distribution\n")
  cat("alternative hypothesis: does not follow the uniform distribution\n")
  cat("decision:",decision,"\n\n")
  cat("Conclusion:",conclusion)
}
