#' Produce random variates from the Bernoulli Distribution
#' 
#' Use Uniform random numbers to generate random variates from a Bernoulli Distribution with parameter p
#' @param rvs The number of random variates to be generated
#' @param p The probability parameter of a Bernoulli Distribution
#' @return A vector of random variates from the Bernoulli Distribution
#' @export
rv.bern <- function(rvs,p){
  variates = c()
  randnums = runif(rvs,0,1)
  for(randnum in randnums){
    if(randnum <= p){
      variates = c(variates,1)
    }else{
      variates = c(variates,0)
    }
  }
  
  return(variates)
}

#' Produce random variates from the Binomial Distribution
#' 
#' Use Uniform random numbers to generate random variates from a Binomial Distribution with parameters n and p
#' @param rvs The number of random variates to be generated
#' @param n The number of trials parameter of a Binomial Distribution
#' @param p The probability parameter of a Binomial Distribution
#' @return A vector of random variates from the Binomial Distribution
#' @export
rv.bin <- function(rvs,n,p){
  variates = c()
  for(rv in 1:rvs){
    count = 0
    for(num in 1:n){
      randnum = runif(1,0,1)
      if(randnum < p) count = count + 1
    }
    variates = c(variates,count)
  }
  
  return(variates)
}

#' Produce random variates from the Geometric Distribution
#' 
#' Use Uniform random numbers to generate random variates from a Geometric Distribution with parameter p
#' @param rvs The number of random variates to be generated
#' @param p The probability parameter of a Geometric Distribution
#' @return A vector of random variates from the Geometric Distribution
#' @export
rv.geom <- function(rvs,p){
  variates = c()
  for(rv in 1:rvs){
    count = 0
    while(TRUE){
      randnum = runif(1,0,1)
      if(randnum < p) break
      else count = count + 1
    }
    variates = c(variates,count)
  }
  
  return(variates)
}

#' Produce random variates from the Poisson Distribution
#' 
#' Use Uniform random numbers to generate random variates from a Poisson Distribution with parameter lambda
#' @param rvs The number of random variates to be generated
#' @param lambda The rate parameter of a Poisson Distribution
#' @return A vector of random variates from the Poisson Distribution
#' @export
rv.pois <- function(rvs,lambda){
  variates = c()
  for(rv in 1:rvs){
    count = 0
    randnum = runif(1,0,1)
    while(randnum > exp(-1*lambda)){
      count = count + 1
      multiplier = runif(1,0,1)
      randnum = randnum * multiplier
    }
    variates = c(variates,count)
  }
  
  return(variates)
}

#' Produce random variates from the Continuous Uniform Distribution
#' 
#' Use Uniform random numbers to generate random variates from a Continuous Uniform Distribution with parameters lower and upper (bounds)
#' @param rvs The number of random variates to be generated
#' @param lower The lower bound of a Continuous Uniform Distribution
#' @param upper The upper bound of a Continuous Uniform Distribution
#' @return A vector of random variates from the Continuous Uniform Distribution
#' @export
rv.unif <- function(rvs,lower,upper){
  variates = c()
  for(rv in 1:rvs){
    randnum = runif(1,0,1)
    variate = (randnum * (upper - lower)) + lower
    variates = c(variates,variate)
  }
  
  return(variates)
}

#' Produce random variates from the Standard Normal Distribution using the Central Limit Theorem
#' 
#' Use Uniform random numbers to generate random variates from a Standard Normal Distribution using the Central Limit Theorem
#' @param rvs The number of random variates to be generated
#' @param rc The number of random numbers to be used in generating a random variate from a Standard Normal Distribution using the Central Limit Theorem
#' @return A vector of random variates from the Standard Normal Distribution
#' @export
rv.norm.CLT <- function(rvs,rc){
  variates = c()
  for(rv in 1:rvs){
    randnums = runif(rc,0,1)
    variate = (sum(randnums) - (rc/2)) / sqrt(rc/12)
    variates = c(variates,variate)
  }
  
  return(variates)
}

#' Produce random variates from the Standard Normal Distribution using the Box-Muller Method
#' 
#' Use Uniform random numbers to generate random variates from a Standard Normal Distribution using the Box-Muller Method. The Box-Muller Method generates two random variates per random number.
#' @param rvps The number of pairs of random variates to be generated
#' @return A vector of random variates from the Standard Normal Distribution
#' @export
rv.norm.BM <- function(rvps){
  variates = c()
  for(rvp in 1:rvps){
    randnum1 = runif(1,0,1)
    randnum2 = runif(1,0,1)
    variate1 = sqrt(-2 * log(randnum1)) * cos(2 * pi * randnum2)
    variate2 = sqrt(-2 * log(randnum1)) * sin(2 * pi * randnum2)
    variates = c(variates,variate1,variate2)
  }
  
  return(variates)
}

#' Produce random variates from the Exponential Distribution
#' 
#' Use Uniform random numbers to generate random variates from an Exponential Distribution with parameter lambda
#' @param rvs The number of random variates to be generated
#' @param lambda The rate parameter of an Exponential Distribution
#' @return A vector of random variates from the Exponential Distribution
#' @export
rv.exp <- function(rvs,lambda){
  variates = c()
  for(rv in 1:rvs){
    randnum = runif(1,0,1)
    variate = (-1 * log(1 - randnum)) / lambda
    variates = c(variates,variate)
  }
  
  return(variates)
}

#' Produce random variates from the Beta Distribution
#' 
#' Use Uniform random numbers to generate random variates from a Beta Distribution with parameters alpha and beta
#' @param rvs The number of random variates to be generated
#' @param alpha The first shape parameter of a Beta Distribution
#' @param beta The second shape parameter of a Beta Distribution
#' @return A vector of random variates from the Beta Distribution
#' @export
rv.beta <- function(rvs,alpha,beta){
  variates = c()
  while(TRUE){
    randnum1 = runif(1,0,1)
    randnum2 = runif(1,0,1)
    
    v1 = randnum1 ^ (1 / alpha)
    v2 = randnum2 ^ (1 / beta)
    check = v1 + v2
    
    if(check > 1) next
    else{
      variate = v1 / check
      variates = c(variates,variate)
    }
    
    if(length(variates)==rvs) break
    else next
  }
  
  return(variates)
}
