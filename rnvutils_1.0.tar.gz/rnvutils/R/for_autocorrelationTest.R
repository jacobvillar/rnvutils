#' Test the independence of selected random numbers using Autocorrelation Test
#' 
#' Performs test of hypothesis on the independence of selected random numbers using Autocorrelation Test
#' @param randnums A vector of random numbers
#' @param start The index of the random number in the vector where the selection starts
#' @param lag The lag or space between the random numbers being tested
#' @param alpha The level of significance for the test of hypothesis
#' @return A test of hypothesis including computed statistic, tabular value, p-value, and conclusion
#' @export
autocorr.test <- function(randnums,start,lag,alpha){
  N = length(randnums)
  M = floor((N - start - lag) / lag)
  
  index = c()
  store = start
  count = 1
  while(TRUE){
    index[count] = store
    count = count + 1
    
    store = store + lag
    if(store > N) break
  }

  if(length(index) <= 1){
    cat("Cannot proceed with the analysis.\n")
    return(NA)
  }
  
  toSum = 0
  for(i in 2:length(index)){
    toSum = toSum + (randnums[index[i]] * randnums[index[i-1]])
  }
  
  
  rho = ((1 / (M + 1)) * toSum) - 0.25
  sigma = sqrt((13 * M) + 7) / (12 * (M + 1))
  
  z.comp = rho / sigma
  z.tab = qnorm(alpha/2,0,1,lower.tail = FALSE)
  pvalue = pnorm(z.comp,0,1,lower.tail = FALSE)
  
  decision = ""
  conclusion = ""
  if(pvalue <= alpha){
    decision = "reject the null hypothesis"
    conclusion = "The selected numbers are not independent."
  }else{
    decision = "fail to reject the null hypothesis"
    conclusion = "The selected numbers are independent."
  }
  
  cat("\n")
  cat("\tAUTOCORRELATION TEST\n")
  cat("\n")
  cat("data:",N,"random numbers\n")
  cat("test: autocorrelation between every",lag,"random numbers\n")
  cat("z = ",z.comp,", tab = ",z.tab,", p-value = ",pvalue,"\n\n",sep="")
  cat("null hypothesis: independent\n")
  cat("alternative hypothesis: not independent\n")
  cat("decision:",decision,"\n\n")
  cat("Conclusion:",conclusion)
}
