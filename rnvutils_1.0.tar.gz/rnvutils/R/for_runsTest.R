#' Determine the number of runs up
#' 
#' Count the number of runs up in a sequence of numbers to be used in the Runs Test
#' @param vec A vector of numbers
#' @return The number of runs up
#' @export
runs.up <- function(vec){
  checkUp=c()
  for(i in 2:length(vec)){
    if(vec[i]>vec[i-1]) checkUp[i-1]=1
    else checkUp[i-1]=0
  }
  
  up=checkUp[1]
  for(j in 2:length(checkUp)){
    if(checkUp[j-1]==0 & checkUp[j]==1) up=up+1
  }
  
  return(up)
}

#' Determine the number of runs down
#' 
#' Count the number of runs down in a sequence of numbers to be used in the Runs Test
#' @param vec A vector of numbers
#' @return The number of runs down
#' @export
runs.down <- function(vec){
  checkDown=c()
  for(i in 2:length(vec)){
    if(vec[i]<vec[i-1]) checkDown[i-1]=1
    else checkDown[i-1]=0
  }
  
  down=checkDown[1]
  for(j in 2:length(checkDown)){
    if(checkDown[j-1]==0 & checkDown[j]==1) down=down+1
  }
  
  return(down)
}

#' Test the independence of random numbers using Runs Test
#' 
#' Performs test of hypothesis on the independence of selected random numbers using Runs Test
#' @param randnums A vector of random numbers
#' @param alpha The level of significance for the test of hypothesis
#' @return A test of hypothesis including computed statistic, tabular value, p-value, and conclusion
#' @export
runs.test <- function(randnums,alpha){
  N = length(randnums)
  runs = runs.up(randnums) + runs.down(randnums)
  
  z.comp = (runs - ((2 * N - 1) / 3)) / (sqrt((16 * N - 29) / 90))
  z.tab = qnorm(alpha/2,0,1,lower.tail = FALSE)
  pvalue = pnorm(z.comp,0,1,lower.tail = FALSE)
  
  decision = ""
  conclusion = ""
  if(pvalue <= alpha){
    decision = "reject the null hypothesis"
    conclusion = "The random numbers are not independent."
  }else{
    decision = "fail to reject the null hypothesis"
    conclusion = "The random numbers are independent."
  }
  
  cat("\n")
  cat("\tRUNS TEST\n")
  cat("\n")
  cat("data:",N,"random numbers\n")
  cat("total runs = ",runs,", runs up = ",runs.up(randnums),", runs down = ",runs.down(randnums),"\n",sep="")
  cat("z = ",z.comp,", tab = ",z.tab,", p-value = ",pvalue,"\n\n",sep="")
  cat("null hypothesis: independent\n")
  cat("alternative hypothesis: not independent\n")
  cat("decision:",decision,"\n\n")
  cat("Conclusion:",conclusion)
}
