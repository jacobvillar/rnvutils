#' Generate random numbers using the theory of linear congruence
#' 
#' Generate uniform random numbers from 0 to 1 inclusive using Linear Congruential Generators (LCGs)
#' @param a1 An integer
#' @param a2 An integer
#' @param k An integer
#' @param w0 The number or a seed to start
#' @param n The number of uniform random numbers to be generated
#' @return A vector of uniform random numbers
#' @export
lin.cg <- function(a1,a2,k,w0,n){
  w=c()
  u=c()
  
  w[1]=((a1*w0)+a2)%%k
  u[1]=w[1]/(k-1)
  
  for(i in 2:n){
    w[i]=((a1*w[i-1])+a2)%%k
    u[i]=w[i]/(k-1)
  }
  
  return(u)
}

#' Generate random numbers using the theory of multiplicative congruence
#' 
#' Generate uniform random numbers from 0 to 1 inclusive using Multiplicative Congruential Generators (LCGs)
#' @param a1 An integer
#' @param k An integer
#' @param w0 The number or a seed to start
#' @param n The number of uniform random numbers to be generated
#' @return A vector of uniform random numbers
#' @export
mult.cg <- function(a1,k,w0,n){
  w=c()
  u=c()
  
  w[1]=(a1*w0)%%k
  u[1]=w[1]/(k-1)
  
  for(i in 2:n){
    w[i]=(a1*w[i-1])%%k
    u[i]=w[i]/(k-1)
  }
  
  return(u)
}

#' Generate random numbers using the theory of inverse congruence
#' 
#' Generate uniform random numbers from 0 to 1 inclusive using Inverse Congruential Generators (LCGs)
#' @param a1 An integer
#' @param a2 An integer
#' @param k An integer
#' @param w0 The number or a seed to start
#' @param n The number of uniform random numbers to be generated
#' @return A vector of uniform random numbers
#' @export
inv.cg <- function(a1,a2,k,w0,n){
  w=c()
  u=c()
  
  w[1]=((a1/w0)+a2)%%k
  u[1]=w[1]/(k-1)
  
  for(i in 2:n){
    w[i]=((a1/w[i-1])+a2)%%k
    u[i]=w[i]/(k-1)
  }
  
  return(u)
}
