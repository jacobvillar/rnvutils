#' Test the independence of random numbers (two digits on decimal) using Poker Test
#' 
#' Performs test of hypothesis on the independence of two-digit decimal numbers using Poker Test
#' @param randnums A vector of two-digit decimal numbers
#' @param alpha The level of significance for the test of hypothesis
#' @return A test of hypothesis including computed statistic, tabular value, p-value, and conclusion
#' @export
poker.test.2d <- function(randnums,alpha){
  n = length(randnums)
  strnums = c()
  for(r in 1:length(randnums)){
    strnum = strsplit(toString(randnums[r]),"\\.")[[1]][2]
    if(length(strsplit(strnum,"")[[1]]) != 2){
      cat("There's a number with invalid number of digits. Make sure that all decimals have only two digits.\n")
      return(NA)
    }else{
      strnums[r] = strnum
    }
  }
  
  obs = c(0,0)
  for(num in strnums){
    check = strsplit(num,"")
    if(check[[1]][1] == check[[1]][2]){
      obs[1] = obs[1] + 1
    }else{
      obs[2] = obs[2] + 1
    }
  }
  
  exp = c(n*0.1,n*0.9)
  
  df = 1
  chi.comp = sum(((obs - exp) ^ 2) / exp)
  chi.tab = qchisq(alpha,df,lower.tail = FALSE)
  pvalue = pchisq(chi.comp,df,lower.tail = FALSE)
  
  decision = ""
  conclusion = ""
  if(pvalue <= alpha){
    decision = "reject the null hypothesis"
    conclusion = "The selected numbers are not independent."
  }else{
    decision = "fail to reject the null hypothesis"
    conclusion = "The selected numbers are independent."
  }
  
  cat("\n")
  cat("\tPOKER TEST (TWO DIGITS)\n")
  cat("\n")
  cat("data:",n,"random numbers\n")
  cat("\tsame digits:",obs[1],"\n")
  cat("\tdiff digits:",obs[2],"\n")
  cat("X-squared = ",chi.comp,", tab = ",chi.tab,", df = ",df,", p-value = ",pvalue,"\n\n",sep="")
  cat("null hypothesis: independent\n")
  cat("alternative hypothesis: not independent\n")
  cat("decision:",decision,"\n\n")
  cat("Conclusion:",conclusion)
}

#' Test the independence of random numbers (three digits on decimal) using Poker Test
#' 
#' Performs test of hypothesis on the independence of three-digit decimal numbers using Poker Test
#' @param randnums A vector of three-digit decimal numbers
#' @param alpha The level of significance for the test of hypothesis
#' @return A test of hypothesis including computed statistic, tabular value, p-value, and conclusion
#' @export
poker.test.3d <- function(randnums,alpha){
  n = length(randnums)
  strnums = c()
  for(r in 1:length(randnums)){
    strnum = strsplit(toString(randnums[r]),"\\.")[[1]][2]
    if(length(strsplit(strnum,"")[[1]]) != 3){
      cat("There's a number with invalid number of digits. Make sure that all decimals have only three digits.\n")
      return(NA)
    }else{
      strnums[r] = strnum
    }
  }
  
  same <- function(a,b){
    if(a==b) return(TRUE)
    else return(FALSE)
  }
  
  obs = c(0,0,0)
  for(num in strnums){
    check = strsplit(num,"")
    a = check[[1]][1]
    b = check[[1]][2]
    c = check[[1]][3]
    if(same(a,b) & same(b,c)){
      obs[2] = obs[2] + 1
    }else if(same(a,b) == F & same(b,c) == F & same(a,c) == F){
      obs[1] = obs[1] + 1
    }else{
      obs[3] = obs[3] + 1
    }
  }
  
  exp = c(n*0.72,n*0.01,n*0.27)
  
  df = 2
  chi.comp = sum(((obs - exp) ^ 2) / exp)
  chi.tab = qchisq(alpha,df,lower.tail = FALSE)
  pvalue = pchisq(chi.comp,df,lower.tail = FALSE)
  
  decision = ""
  conclusion = ""
  if(pvalue <= alpha){
    decision = "reject the null hypothesis"
    conclusion = "The selected numbers are not independent."
  }else{
    decision = "fail to reject the null hypothesis"
    conclusion = "The selected numbers are independent."
  }
  
  cat("\n")
  cat("\tPOKER TEST (THREE DIGITS)\n")
  cat("\n")
  cat("data:",n,"random numbers\n")
  cat("\tthree diff digits:",obs[1],"\n")
  cat("\tthree same digits:",obs[2],"\n")
  cat("\texactly one pair:",obs[3],"\n")
  cat("X-squared = ",chi.comp,", tab = ",chi.tab,", df = ",df,", p-value = ",pvalue,"\n\n",sep="")
  cat("null hypothesis: independent\n")
  cat("alternative hypothesis: not independent\n")
  cat("decision:",decision,"\n\n")
  cat("Conclusion:",conclusion)
}

#' Test the independence of random numbers (four digits on decimal) using Poker Test
#' 
#' Performs test of hypothesis on the independence of four-digit decimal numbers using Poker Test
#' @param randnums A vector of four-digit decimal numbers
#' @param alpha The level of significance for the test of hypothesis
#' @return A test of hypothesis including computed statistic, tabular value, p-value, and conclusion
#' @export
poker.test.4d <- function(randnums,alpha){
  n = length(randnums)
  strnums = c()
  for(r in 1:length(randnums)){
    strnum = strsplit(toString(randnums[r]),"\\.")[[1]][2]
    if(length(strsplit(strnum,"")[[1]]) != 4){
      cat("There's a number with invalid number of digits. Make sure that all decimals have only four digits.\n")
      return(NA)
    }else{
      strnums[r] = strnum
    }
  }
  
  obs = c(0,0,0,0,0)
  comp = c(0:9)
  res = rep(0,10)
  for(num in strnums){
    check = strsplit(num,"")
    for(c in check[[1]]){
      for(d in comp){
        if(c == toString(d)) res[d + 1] = res[d + 1] + 1
      }
    }
    
    if(4 %in% res) obs[3] = obs[3] + 1
    else if(3 %in% res) obs[2] = obs[2] + 1
    else if(2 %in% res){
      freq2 = 0
      for(x in res){
        if(x==2) freq2 = freq2 + 1
      }
      
      if(freq2 == 2) obs[5] = obs[5] + 1
      else obs[4] = obs[4] + 1
    }
    res = rep(0,10)
  }
  
  obs[1] = n - sum(obs[2:5])
  
  exp = c(n*0.504,n*0.036,n*0.001,n*0.432,n*027)

  df = 4
  chi.comp = sum(((obs - exp) ^ 2) / exp)
  chi.tab = qchisq(alpha,df,lower.tail = FALSE)
  pvalue = pchisq(chi.comp,df,lower.tail = FALSE)

  decision = ""
  conclusion = ""
  if(pvalue <= alpha){
    decision = "reject the null hypothesis"
    conclusion = "The selected numbers are not independent."
  }else{
    decision = "fail to reject the null hypothesis"
    conclusion = "The selected numbers are independent."
  }

  cat("\n")
  cat("\tPOKER TEST (FOUR DIGITS)\n")
  cat("\n")
  cat("data:",n,"random numbers\n")
  cat("\tfour diff digits:",obs[1],"\n")
  cat("\tthree same digits:",obs[2],"\n")
  cat("\tfour same digits:",obs[3],"\n")
  cat("\texactly one pair:",obs[4],"\n")
  cat("\texactly two pairs:",obs[5],"\n")
  cat("X-squared = ",chi.comp,", tab = ",chi.tab,", df = ",df,", p-value = ",pvalue,"\n\n",sep="")
  cat("null hypothesis: independent\n")
  cat("alternative hypothesis: not independent\n")
  cat("decision:",decision,"\n\n")
  cat("Conclusion:",conclusion)
}
